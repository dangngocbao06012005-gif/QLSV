using System;
using System.Data;
using Btap_QLSV.DAL;

namespace Btap_QLSV.BLL
{
    internal sealed class SinhVienService
    {
        private readonly SinhVienRepository _repo = new SinhVienRepository();

        public DataTable GetAll() => _repo.GetAll();
        public DataTable Search(string keyword) => _repo.Search(keyword ?? "");

        public int Add(string maSv, string hoTen, DateTime ngaySinh, string gioiTinh, string diaChi, string maLop)
            => _repo.Insert(maSv?.Trim(), hoTen?.Trim(), ngaySinh, gioiTinh?.Trim(), diaChi?.Trim(), maLop?.Trim());

        public int Update(string maSv, string hoTen, DateTime ngaySinh, string gioiTinh, string diaChi, string maLop)
            => _repo.Update(maSv?.Trim(), hoTen?.Trim(), ngaySinh, gioiTinh?.Trim(), diaChi?.Trim(), maLop?.Trim());

        public int Delete(string maSv) => _repo.Delete(maSv?.Trim());
    }
}

