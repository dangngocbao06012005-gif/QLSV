using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Btap_QLSV
{
    internal static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            // Form1: Đăng nhập
            // Sau khi login OK, Form1 sẽ mở FrmMain (quản lý SV/Lớp)
            Application.Run(new Form1());
        }
    }
}
