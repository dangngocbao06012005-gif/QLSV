using System;
using Btap_QLSV.DAL;

namespace Btap_QLSV.BLL
{
    internal sealed class AuthService
    {
        private readonly TaiKhoanRepository _repo = new TaiKhoanRepository();

        public bool Login(string username, string passwordPlain)
        {
            if (string.IsNullOrWhiteSpace(username) || string.IsNullOrWhiteSpace(passwordPlain))
                return false;

            var plain = passwordPlain.Trim();
            var hash = PasswordHasher.Sha256Hex(plain);
            return _repo.ValidateLogin(username.Trim(), plain, hash);
        }
    }
}

