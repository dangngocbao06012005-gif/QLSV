using System.Data;
using Btap_QLSV.DAL;

namespace Btap_QLSV.BLL
{
    internal sealed class LopService
    {
        private readonly LopRepository _repo = new LopRepository();

        public DataTable GetAll() => _repo.GetAll();
        public DataTable Search(string keyword) => _repo.Search(keyword ?? "");

        public int Add(string maLop, string tenLop) => _repo.Insert(maLop?.Trim(), tenLop?.Trim());
        public int Update(string maLop, string tenLop) => _repo.Update(maLop?.Trim(), tenLop?.Trim());
        public int Delete(string maLop) => _repo.Delete(maLop?.Trim());
    }
}

