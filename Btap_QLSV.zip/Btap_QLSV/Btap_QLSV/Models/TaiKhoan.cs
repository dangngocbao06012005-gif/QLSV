namespace Btap_QLSV.Models
{
    public class TaiKhoan
    {
        public string Username { get; set; }
        public string PasswordHash { get; set; }
    }
}

