using System.Data;
using System.Data.SqlClient;

namespace Btap_QLSV.DAL
{
    internal sealed class LopRepository
    {
        public DataTable GetAll()
        {
            const string sql = @"SELECT MaLop, TenLop FROM dbo.Lop ORDER BY MaLop;";
            return Db.ExecuteDataTable(sql);
        }

        public DataTable Search(string keyword)
        {
            const string sql = @"
SELECT MaLop, TenLop
FROM dbo.Lop
WHERE MaLop LIKE @kw OR TenLop LIKE @kw
ORDER BY MaLop;";

            return Db.ExecuteDataTable(sql, new SqlParameter("@kw", $"%{keyword}%"));
        }

        public int Insert(string maLop, string tenLop)
        {
            const string sql = @"INSERT INTO dbo.Lop(MaLop, TenLop) VALUES (@MaLop, @TenLop);";
            return Db.ExecuteNonQuery(sql,
                new SqlParameter("@MaLop", maLop),
                new SqlParameter("@TenLop", tenLop)
            );
        }

        public int Update(string maLop, string tenLop)
        {
            const string sql = @"UPDATE dbo.Lop SET TenLop = @TenLop WHERE MaLop = @MaLop;";
            return Db.ExecuteNonQuery(sql,
                new SqlParameter("@MaLop", maLop),
                new SqlParameter("@TenLop", tenLop)
            );
        }

        public int Delete(string maLop)
        {
            const string sql = @"DELETE FROM dbo.Lop WHERE MaLop = @MaLop;";
            return Db.ExecuteNonQuery(sql, new SqlParameter("@MaLop", maLop));
        }
    }
}

