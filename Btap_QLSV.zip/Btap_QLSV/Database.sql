-- SQL Server: Tạo database + bảng TaiKhoan, Lop, SinhVien
-- Chạy script này trong SSMS.

IF DB_ID(N'QuanLySinhVienDaiHoc') IS NULL
BEGIN
    CREATE DATABASE QuanLySinhVienDaiHoc;
END
GO

USE QuanLySinhVienDaiHoc;
GO

IF OBJECT_ID(N'dbo.SinhVien', N'U') IS NOT NULL DROP TABLE dbo.SinhVien;
IF OBJECT_ID(N'dbo.Lop', N'U') IS NOT NULL DROP TABLE dbo.Lop;
IF OBJECT_ID(N'dbo.TaiKhoan', N'U') IS NOT NULL DROP TABLE dbo.TaiKhoan;
GO

CREATE TABLE dbo.TaiKhoan
(
    Username     NVARCHAR(50)  NOT NULL PRIMARY KEY,
    PasswordHash NVARCHAR(64)  NOT NULL  -- SHA256 hex
);
GO

CREATE TABLE dbo.Lop
(
    MaLop  NVARCHAR(20)  NOT NULL PRIMARY KEY,
    TenLop NVARCHAR(100) NOT NULL
);
GO

CREATE TABLE dbo.SinhVien
(
    MaSV     NVARCHAR(20)  NOT NULL PRIMARY KEY,
    HoTen    NVARCHAR(100) NOT NULL,
    NgaySinh DATE          NOT NULL,
    GioiTinh NVARCHAR(10)  NOT NULL,
    DiaChi   NVARCHAR(200) NULL,
    MaLop    NVARCHAR(20)  NOT NULL,
    CONSTRAINT FK_SinhVien_Lop FOREIGN KEY (MaLop) REFERENCES dbo.Lop(MaLop)
);
GO

-- Tài khoản mẫu: admin / 123
-- SHA256("123") = a665a45920422f9d417e4867efdc4fb8a04a1f3fff1fa07e998e86f7f7a27ae3
INSERT INTO dbo.TaiKhoan(Username, PasswordHash)
VALUES (N'admin', N'a665a45920422f9d417e4867efdc4fb8a04a1f3fff1fa07e998e86f7f7a27ae3');
GO

-- Dữ liệu lớp mẫu
INSERT INTO dbo.Lop(MaLop, TenLop)
VALUES
(N'CNTT01', N'Công nghệ thông tin 01'),
(N'CNTT02', N'Công nghệ thông tin 02');
GO

-- Dữ liệu sinh viên mẫu
INSERT INTO dbo.SinhVien(MaSV, HoTen, NgaySinh, GioiTinh, DiaChi, MaLop)
VALUES
(N'SV001', N'Nguyễn Văn A', '2004-01-15', N'Nam', N'Hà Nội', N'CNTT01'),
(N'SV002', N'Trần Thị B',  '2004-05-20', N'Nữ',  N'Đà Nẵng', N'CNTT02');
GO

