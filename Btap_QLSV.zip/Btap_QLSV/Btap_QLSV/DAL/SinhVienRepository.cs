using System;
using System.Data;
using System.Data.SqlClient;

namespace Btap_QLSV.DAL
{
    internal sealed class SinhVienRepository
    {
        public DataTable GetAll()
        {
            const string sql = @"
SELECT sv.MaSV, sv.HoTen, sv.NgaySinh, sv.GioiTinh, sv.DiaChi, sv.MaLop, l.TenLop
FROM dbo.SinhVien sv
INNER JOIN dbo.Lop l ON l.MaLop = sv.MaLop
ORDER BY sv.MaSV;";
            return Db.ExecuteDataTable(sql);
        }

        public DataTable Search(string keyword)
        {
            const string sql = @"
SELECT sv.MaSV, sv.HoTen, sv.NgaySinh, sv.GioiTinh, sv.DiaChi, sv.MaLop, l.TenLop
FROM dbo.SinhVien sv
INNER JOIN dbo.Lop l ON l.MaLop = sv.MaLop
WHERE sv.MaSV LIKE @kw OR sv.HoTen LIKE @kw OR sv.DiaChi LIKE @kw OR sv.MaLop LIKE @kw OR l.TenLop LIKE @kw
ORDER BY sv.MaSV;";

            return Db.ExecuteDataTable(sql, new SqlParameter("@kw", $"%{keyword}%"));
        }

        public int Insert(string maSv, string hoTen, DateTime ngaySinh, string gioiTinh, string diaChi, string maLop)
        {
            const string sql = @"
INSERT INTO dbo.SinhVien(MaSV, HoTen, NgaySinh, GioiTinh, DiaChi, MaLop)
VALUES (@MaSV, @HoTen, @NgaySinh, @GioiTinh, @DiaChi, @MaLop);";

            return Db.ExecuteNonQuery(sql,
                new SqlParameter("@MaSV", maSv),
                new SqlParameter("@HoTen", hoTen),
                new SqlParameter("@NgaySinh", ngaySinh),
                new SqlParameter("@GioiTinh", gioiTinh),
                new SqlParameter("@DiaChi", (object)diaChi ?? DBNull.Value),
                new SqlParameter("@MaLop", maLop)
            );
        }

        public int Update(string maSv, string hoTen, DateTime ngaySinh, string gioiTinh, string diaChi, string maLop)
        {
            const string sql = @"
UPDATE dbo.SinhVien
SET HoTen = @HoTen,
    NgaySinh = @NgaySinh,
    GioiTinh = @GioiTinh,
    DiaChi = @DiaChi,
    MaLop = @MaLop
WHERE MaSV = @MaSV;";

            return Db.ExecuteNonQuery(sql,
                new SqlParameter("@MaSV", maSv),
                new SqlParameter("@HoTen", hoTen),
                new SqlParameter("@NgaySinh", ngaySinh),
                new SqlParameter("@GioiTinh", gioiTinh),
                new SqlParameter("@DiaChi", (object)diaChi ?? DBNull.Value),
                new SqlParameter("@MaLop", maLop)
            );
        }

        public int Delete(string maSv)
        {
            const string sql = @"DELETE FROM dbo.SinhVien WHERE MaSV = @MaSV;";
            return Db.ExecuteNonQuery(sql, new SqlParameter("@MaSV", maSv));
        }
    }
}

