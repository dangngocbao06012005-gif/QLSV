# Btap_QLSV - Quản lý sinh viên (WinForms + SQL Server)

## 1) Tạo database

- Mở SQL Server Management Studio (SSMS)
- Chạy file script: `Database.sql`

Tài khoản mẫu:
- Username: `admin`
- Password: `123`

## 2) Cấu hình kết nối

Mở `Btap_QLSV/Btap_QLSV/App.config` và sửa `Data Source=...` cho đúng SQL Server của bạn.

Connection string đang dùng (name):
- `Btap_QLSV.Properties.Settings.QuanLySinhVienDaiHocConnectionString`

## 3) Chạy chương trình

- Mở `Btap_QLSV.sln` bằng Visual Studio
- Run project `Btap_QLSV`

Luồng chạy:
- `FrmLogin` → kiểm tra bảng `TaiKhoan`
- Đăng nhập OK → mở `FrmMain` (tab Sinh viên/Lớp)

