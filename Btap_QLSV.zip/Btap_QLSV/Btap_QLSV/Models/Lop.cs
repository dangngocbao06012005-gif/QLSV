namespace Btap_QLSV.Models
{
    public class Lop
    {
        public string MaLop { get; set; }
        public string TenLop { get; set; }

        public override string ToString() => $"{MaLop} - {TenLop}";
    }
}

