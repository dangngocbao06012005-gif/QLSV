using System;
using System.Data;
using System.Data.SqlClient;

namespace Btap_QLSV.DAL
{
    internal sealed class TaiKhoanRepository
    {
        private static bool HasColumn(DataTable cols, string columnName)
        {
            if (cols == null) return false;
            foreach (DataRow r in cols.Rows)
            {
                var name = r["name"]?.ToString();
                if (string.Equals(name, columnName, StringComparison.OrdinalIgnoreCase))
                    return true;
            }
            return false;
        }

        private static DataTable GetTaiKhoanColumns()
        {
            const string sql = @"
SELECT c.name
FROM sys.columns c
WHERE c.object_id = OBJECT_ID(N'dbo.TaiKhoan');";
            return Db.ExecuteDataTable(sql);
        }

        public bool ValidateLogin(string username, string passwordPlain, string passwordHash)
        {
            var cols = GetTaiKhoanColumns();

            // Username column candidates
            var userCol = HasColumn(cols, "Username") ? "Username"
                       : HasColumn(cols, "TenDangNhap") ? "TenDangNhap"
                       : null;

            if (string.IsNullOrWhiteSpace(userCol))
                throw new InvalidOperationException("Bảng dbo.TaiKhoan không có cột Username/TenDangNhap.");

            // Password column candidates
            var passCol = HasColumn(cols, "PasswordHash") ? "PasswordHash"
                       : HasColumn(cols, "Password") ? "Password"
                       : HasColumn(cols, "MatKhau") ? "MatKhau"
                       : null;

            if (string.IsNullOrWhiteSpace(passCol))
                throw new InvalidOperationException("Bảng dbo.TaiKhoan không có cột PasswordHash/Password/MatKhau.");

            var compareValue = string.Equals(passCol, "PasswordHash", StringComparison.OrdinalIgnoreCase)
                ? passwordHash
                : passwordPlain;

            object result;
            if (string.Equals(passCol, "PasswordHash", StringComparison.OrdinalIgnoreCase))
            {
                // DB có thể lưu hash hoặc lưu plain (nhưng đặt tên cột là PasswordHash).
                var sql = $@"
SELECT COUNT(1)
FROM dbo.TaiKhoan
WHERE [{userCol}] = @u AND ([{passCol}] = @hash OR [{passCol}] = @plain);";

                result = Db.ExecuteScalar(sql,
                    new SqlParameter("@u", username),
                    new SqlParameter("@hash", passwordHash),
                    new SqlParameter("@plain", passwordPlain)
                );
            }
            else
            {
                var sql = $@"
SELECT COUNT(1)
FROM dbo.TaiKhoan
WHERE [{userCol}] = @u AND [{passCol}] = @p;";

                result = Db.ExecuteScalar(sql,
                    new SqlParameter("@u", username),
                    new SqlParameter("@p", compareValue)
                );
            }

            return result != null && (int)result > 0;
        }
    }
}

