namespace Btap_QLSV.UI
{
    partial class FrmMain
    {
        private System.ComponentModel.IContainer components = null;

        private System.Windows.Forms.Label lblWelcome;
        private System.Windows.Forms.TabControl tabControl;
        private System.Windows.Forms.TabPage tabSinhVien;
        private System.Windows.Forms.TabPage tabLop;

        private System.Windows.Forms.DataGridView dgvSinhVien;
        private System.Windows.Forms.GroupBox grpSinhVien;
        private System.Windows.Forms.TextBox txtMaSV;
        private System.Windows.Forms.TextBox txtHoTen;
        private System.Windows.Forms.DateTimePicker dtpNgaySinh;
        private System.Windows.Forms.ComboBox cboGioiTinh;
        private System.Windows.Forms.TextBox txtDiaChi;
        private System.Windows.Forms.ComboBox cboSvLop;
        private System.Windows.Forms.Button btnSvAdd;
        private System.Windows.Forms.Button btnSvUpdate;
        private System.Windows.Forms.Button btnSvDelete;
        private System.Windows.Forms.Button btnSvClear;
        private System.Windows.Forms.TextBox txtSvSearch;
        private System.Windows.Forms.Button btnSvSearch;
        private System.Windows.Forms.Button btnSvReload;

        private System.Windows.Forms.DataGridView dgvLop;
        private System.Windows.Forms.GroupBox grpLop;
        private System.Windows.Forms.TextBox txtMaLop;
        private System.Windows.Forms.TextBox txtTenLop;
        private System.Windows.Forms.Button btnLopAdd;
        private System.Windows.Forms.Button btnLopUpdate;
        private System.Windows.Forms.Button btnLopDelete;
        private System.Windows.Forms.Button btnLopClear;
        private System.Windows.Forms.TextBox txtLopSearch;
        private System.Windows.Forms.Button btnLopSearch;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.lblWelcome = new System.Windows.Forms.Label();
            this.tabControl = new System.Windows.Forms.TabControl();
            this.tabSinhVien = new System.Windows.Forms.TabPage();
            this.btnSvReload = new System.Windows.Forms.Button();
            this.btnSvSearch = new System.Windows.Forms.Button();
            this.txtSvSearch = new System.Windows.Forms.TextBox();
            this.grpSinhVien = new System.Windows.Forms.GroupBox();
            this.txtMaSV = new System.Windows.Forms.TextBox();
            this.txtHoTen = new System.Windows.Forms.TextBox();
            this.dtpNgaySinh = new System.Windows.Forms.DateTimePicker();
            this.cboGioiTinh = new System.Windows.Forms.ComboBox();
            this.txtDiaChi = new System.Windows.Forms.TextBox();
            this.cboSvLop = new System.Windows.Forms.ComboBox();
            this.btnSvAdd = new System.Windows.Forms.Button();
            this.btnSvUpdate = new System.Windows.Forms.Button();
            this.btnSvDelete = new System.Windows.Forms.Button();
            this.btnSvClear = new System.Windows.Forms.Button();
            this.dgvSinhVien = new System.Windows.Forms.DataGridView();
            this.tabLop = new System.Windows.Forms.TabPage();
            this.btnLopSearch = new System.Windows.Forms.Button();
            this.txtLopSearch = new System.Windows.Forms.TextBox();
            this.grpLop = new System.Windows.Forms.GroupBox();
            this.txtMaLop = new System.Windows.Forms.TextBox();
            this.txtTenLop = new System.Windows.Forms.TextBox();
            this.btnLopAdd = new System.Windows.Forms.Button();
            this.btnLopUpdate = new System.Windows.Forms.Button();
            this.btnLopDelete = new System.Windows.Forms.Button();
            this.btnLopClear = new System.Windows.Forms.Button();
            this.dgvLop = new System.Windows.Forms.DataGridView();
            this.tabControl.SuspendLayout();
            this.tabSinhVien.SuspendLayout();
            this.grpSinhVien.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvSinhVien)).BeginInit();
            this.tabLop.SuspendLayout();
            this.grpLop.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvLop)).BeginInit();
            this.SuspendLayout();
            // 
            // lblWelcome
            // 
            this.lblWelcome.AutoSize = true;
            this.lblWelcome.Location = new System.Drawing.Point(12, 12);
            this.lblWelcome.Name = "lblWelcome";
            this.lblWelcome.Size = new System.Drawing.Size(110, 20);
            this.lblWelcome.TabIndex = 0;
            this.lblWelcome.Text = "Xin chào: (user)";
            // 
            // tabControl
            // 
            this.tabControl.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tabControl.Controls.Add(this.tabSinhVien);
            this.tabControl.Controls.Add(this.tabLop);
            this.tabControl.Location = new System.Drawing.Point(12, 44);
            this.tabControl.Name = "tabControl";
            this.tabControl.SelectedIndex = 0;
            this.tabControl.Size = new System.Drawing.Size(1160, 640);
            this.tabControl.TabIndex = 1;
            // 
            // tabSinhVien
            // 
            this.tabSinhVien.Controls.Add(this.btnSvReload);
            this.tabSinhVien.Controls.Add(this.btnSvSearch);
            this.tabSinhVien.Controls.Add(this.txtSvSearch);
            this.tabSinhVien.Controls.Add(this.grpSinhVien);
            this.tabSinhVien.Controls.Add(this.dgvSinhVien);
            this.tabSinhVien.Location = new System.Drawing.Point(4, 29);
            this.tabSinhVien.Name = "tabSinhVien";
            this.tabSinhVien.Padding = new System.Windows.Forms.Padding(3);
            this.tabSinhVien.Size = new System.Drawing.Size(1152, 607);
            this.tabSinhVien.TabIndex = 0;
            this.tabSinhVien.Text = "Sinh viên";
            this.tabSinhVien.UseVisualStyleBackColor = true;
            // 
            // btnSvReload
            // 
            this.btnSvReload.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnSvReload.Location = new System.Drawing.Point(1045, 10);
            this.btnSvReload.Name = "btnSvReload";
            this.btnSvReload.Size = new System.Drawing.Size(95, 30);
            this.btnSvReload.TabIndex = 2;
            this.btnSvReload.Text = "Tải lại";
            this.btnSvReload.UseVisualStyleBackColor = true;
            this.btnSvReload.Click += new System.EventHandler(this.btnSvReload_Click);
            // 
            // btnSvSearch
            // 
            this.btnSvSearch.Location = new System.Drawing.Point(296, 10);
            this.btnSvSearch.Name = "btnSvSearch";
            this.btnSvSearch.Size = new System.Drawing.Size(95, 30);
            this.btnSvSearch.TabIndex = 1;
            this.btnSvSearch.Text = "Tìm";
            this.btnSvSearch.UseVisualStyleBackColor = true;
            this.btnSvSearch.Click += new System.EventHandler(this.btnSvSearch_Click);
            // 
            // txtSvSearch
            // 
            this.txtSvSearch.Location = new System.Drawing.Point(10, 11);
            this.txtSvSearch.Name = "txtSvSearch";
            this.txtSvSearch.Size = new System.Drawing.Size(276, 27);
            this.txtSvSearch.TabIndex = 0;
            this.txtSvSearch.TextChanged += new System.EventHandler(this.txtSvSearch_TextChanged);
            // 
            // grpSinhVien
            // 
            this.grpSinhVien.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.grpSinhVien.Controls.Add(this.txtMaSV);
            this.grpSinhVien.Controls.Add(this.txtHoTen);
            this.grpSinhVien.Controls.Add(this.dtpNgaySinh);
            this.grpSinhVien.Controls.Add(this.cboGioiTinh);
            this.grpSinhVien.Controls.Add(this.txtDiaChi);
            this.grpSinhVien.Controls.Add(this.cboSvLop);
            this.grpSinhVien.Controls.Add(this.btnSvAdd);
            this.grpSinhVien.Controls.Add(this.btnSvUpdate);
            this.grpSinhVien.Controls.Add(this.btnSvDelete);
            this.grpSinhVien.Controls.Add(this.btnSvClear);
            this.grpSinhVien.Location = new System.Drawing.Point(10, 385);
            this.grpSinhVien.Name = "grpSinhVien";
            this.grpSinhVien.Size = new System.Drawing.Size(1130, 210);
            this.grpSinhVien.TabIndex = 4;
            this.grpSinhVien.TabStop = false;
            this.grpSinhVien.Text = "Thông tin sinh viên";
            this.grpSinhVien.Enter += new System.EventHandler(this.grpSinhVien_Enter);
            // 
            // txtMaSV
            // 
            this.txtMaSV.Location = new System.Drawing.Point(110, 25);
            this.txtMaSV.Name = "txtMaSV";
            this.txtMaSV.Size = new System.Drawing.Size(280, 27);
            this.txtMaSV.TabIndex = 0;
            // 
            // txtHoTen
            // 
            this.txtHoTen.Location = new System.Drawing.Point(110, 59);
            this.txtHoTen.Name = "txtHoTen";
            this.txtHoTen.Size = new System.Drawing.Size(280, 27);
            this.txtHoTen.TabIndex = 1;
            // 
            // dtpNgaySinh
            // 
            this.dtpNgaySinh.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpNgaySinh.Location = new System.Drawing.Point(110, 93);
            this.dtpNgaySinh.Name = "dtpNgaySinh";
            this.dtpNgaySinh.Size = new System.Drawing.Size(280, 27);
            this.dtpNgaySinh.TabIndex = 2;
            // 
            // cboGioiTinh
            // 
            this.cboGioiTinh.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboGioiTinh.FormattingEnabled = true;
            this.cboGioiTinh.Items.AddRange(new object[] {
            "Nam",
            "Nữ",
            "Khác"});
            this.cboGioiTinh.Location = new System.Drawing.Point(110, 127);
            this.cboGioiTinh.Name = "cboGioiTinh";
            this.cboGioiTinh.Size = new System.Drawing.Size(280, 28);
            this.cboGioiTinh.TabIndex = 3;
            // 
            // txtDiaChi
            // 
            this.txtDiaChi.Location = new System.Drawing.Point(500, 25);
            this.txtDiaChi.Name = "txtDiaChi";
            this.txtDiaChi.Size = new System.Drawing.Size(300, 27);
            this.txtDiaChi.TabIndex = 4;
            // 
            // cboSvLop
            // 
            this.cboSvLop.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboSvLop.FormattingEnabled = true;
            this.cboSvLop.Location = new System.Drawing.Point(500, 59);
            this.cboSvLop.Name = "cboSvLop";
            this.cboSvLop.Size = new System.Drawing.Size(300, 28);
            this.cboSvLop.TabIndex = 5;
            // 
            // btnSvAdd
            // 
            this.btnSvAdd.Location = new System.Drawing.Point(840, 25);
            this.btnSvAdd.Name = "btnSvAdd";
            this.btnSvAdd.Size = new System.Drawing.Size(120, 34);
            this.btnSvAdd.TabIndex = 6;
            this.btnSvAdd.Text = "Thêm";
            this.btnSvAdd.UseVisualStyleBackColor = true;
            this.btnSvAdd.Click += new System.EventHandler(this.btnSvAdd_Click);
            // 
            // btnSvUpdate
            // 
            this.btnSvUpdate.Location = new System.Drawing.Point(840, 65);
            this.btnSvUpdate.Name = "btnSvUpdate";
            this.btnSvUpdate.Size = new System.Drawing.Size(120, 34);
            this.btnSvUpdate.TabIndex = 7;
            this.btnSvUpdate.Text = "Sửa";
            this.btnSvUpdate.UseVisualStyleBackColor = true;
            this.btnSvUpdate.Click += new System.EventHandler(this.btnSvUpdate_Click);
            // 
            // btnSvDelete
            // 
            this.btnSvDelete.Location = new System.Drawing.Point(840, 105);
            this.btnSvDelete.Name = "btnSvDelete";
            this.btnSvDelete.Size = new System.Drawing.Size(120, 34);
            this.btnSvDelete.TabIndex = 8;
            this.btnSvDelete.Text = "Xóa";
            this.btnSvDelete.UseVisualStyleBackColor = true;
            this.btnSvDelete.Click += new System.EventHandler(this.btnSvDelete_Click);
            // 
            // btnSvClear
            // 
            this.btnSvClear.Location = new System.Drawing.Point(840, 145);
            this.btnSvClear.Name = "btnSvClear";
            this.btnSvClear.Size = new System.Drawing.Size(120, 34);
            this.btnSvClear.TabIndex = 9;
            this.btnSvClear.Text = "Làm mới";
            this.btnSvClear.UseVisualStyleBackColor = true;
            this.btnSvClear.Click += new System.EventHandler(this.btnSvClear_Click);
            // 
            // dgvSinhVien
            // 
            this.dgvSinhVien.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dgvSinhVien.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvSinhVien.Location = new System.Drawing.Point(10, 50);
            this.dgvSinhVien.MultiSelect = false;
            this.dgvSinhVien.Name = "dgvSinhVien";
            this.dgvSinhVien.ReadOnly = true;
            this.dgvSinhVien.RowHeadersWidth = 51;
            this.dgvSinhVien.RowTemplate.Height = 29;
            this.dgvSinhVien.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvSinhVien.Size = new System.Drawing.Size(1130, 325);
            this.dgvSinhVien.TabIndex = 3;
            this.dgvSinhVien.SelectionChanged += new System.EventHandler(this.dgvSinhVien_SelectionChanged);
            // 
            // tabLop
            // 
            this.tabLop.Controls.Add(this.btnLopSearch);
            this.tabLop.Controls.Add(this.txtLopSearch);
            this.tabLop.Controls.Add(this.grpLop);
            this.tabLop.Controls.Add(this.dgvLop);
            this.tabLop.Location = new System.Drawing.Point(4, 29);
            this.tabLop.Name = "tabLop";
            this.tabLop.Padding = new System.Windows.Forms.Padding(3);
            this.tabLop.Size = new System.Drawing.Size(1152, 607);
            this.tabLop.TabIndex = 1;
            this.tabLop.Text = "Lớp";
            this.tabLop.UseVisualStyleBackColor = true;
            // 
            // btnLopSearch
            // 
            this.btnLopSearch.Location = new System.Drawing.Point(296, 10);
            this.btnLopSearch.Name = "btnLopSearch";
            this.btnLopSearch.Size = new System.Drawing.Size(95, 30);
            this.btnLopSearch.TabIndex = 1;
            this.btnLopSearch.Text = "Tìm";
            this.btnLopSearch.UseVisualStyleBackColor = true;
            this.btnLopSearch.Click += new System.EventHandler(this.btnLopSearch_Click);
            // 
            // txtLopSearch
            // 
            this.txtLopSearch.Location = new System.Drawing.Point(10, 11);
            this.txtLopSearch.Name = "txtLopSearch";
            this.txtLopSearch.Size = new System.Drawing.Size(276, 27);
            this.txtLopSearch.TabIndex = 0;
            // 
            // grpLop
            // 
            this.grpLop.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.grpLop.Controls.Add(this.txtMaLop);
            this.grpLop.Controls.Add(this.txtTenLop);
            this.grpLop.Controls.Add(this.btnLopAdd);
            this.grpLop.Controls.Add(this.btnLopUpdate);
            this.grpLop.Controls.Add(this.btnLopDelete);
            this.grpLop.Controls.Add(this.btnLopClear);
            this.grpLop.Location = new System.Drawing.Point(10, 420);
            this.grpLop.Name = "grpLop";
            this.grpLop.Size = new System.Drawing.Size(1130, 175);
            this.grpLop.TabIndex = 3;
            this.grpLop.TabStop = false;
            this.grpLop.Text = "Quản lý lớp";
            // 
            // txtMaLop
            // 
            this.txtMaLop.Location = new System.Drawing.Point(110, 29);
            this.txtMaLop.Name = "txtMaLop";
            this.txtMaLop.Size = new System.Drawing.Size(280, 27);
            this.txtMaLop.TabIndex = 0;
            // 
            // txtTenLop
            // 
            this.txtTenLop.Location = new System.Drawing.Point(110, 67);
            this.txtTenLop.Name = "txtTenLop";
            this.txtTenLop.Size = new System.Drawing.Size(520, 27);
            this.txtTenLop.TabIndex = 1;
            // 
            // btnLopAdd
            // 
            this.btnLopAdd.Location = new System.Drawing.Point(680, 29);
            this.btnLopAdd.Name = "btnLopAdd";
            this.btnLopAdd.Size = new System.Drawing.Size(120, 34);
            this.btnLopAdd.TabIndex = 2;
            this.btnLopAdd.Text = "Thêm";
            this.btnLopAdd.UseVisualStyleBackColor = true;
            this.btnLopAdd.Click += new System.EventHandler(this.btnLopAdd_Click);
            // 
            // btnLopUpdate
            // 
            this.btnLopUpdate.Location = new System.Drawing.Point(680, 69);
            this.btnLopUpdate.Name = "btnLopUpdate";
            this.btnLopUpdate.Size = new System.Drawing.Size(120, 34);
            this.btnLopUpdate.TabIndex = 3;
            this.btnLopUpdate.Text = "Sửa";
            this.btnLopUpdate.UseVisualStyleBackColor = true;
            this.btnLopUpdate.Click += new System.EventHandler(this.btnLopUpdate_Click);
            // 
            // btnLopDelete
            // 
            this.btnLopDelete.Location = new System.Drawing.Point(680, 109);
            this.btnLopDelete.Name = "btnLopDelete";
            this.btnLopDelete.Size = new System.Drawing.Size(120, 34);
            this.btnLopDelete.TabIndex = 4;
            this.btnLopDelete.Text = "Xóa";
            this.btnLopDelete.UseVisualStyleBackColor = true;
            this.btnLopDelete.Click += new System.EventHandler(this.btnLopDelete_Click);
            // 
            // btnLopClear
            // 
            this.btnLopClear.Location = new System.Drawing.Point(820, 29);
            this.btnLopClear.Name = "btnLopClear";
            this.btnLopClear.Size = new System.Drawing.Size(120, 34);
            this.btnLopClear.TabIndex = 5;
            this.btnLopClear.Text = "Làm mới";
            this.btnLopClear.UseVisualStyleBackColor = true;
            this.btnLopClear.Click += new System.EventHandler(this.btnLopClear_Click);
            // 
            // dgvLop
            // 
            this.dgvLop.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dgvLop.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvLop.Location = new System.Drawing.Point(10, 50);
            this.dgvLop.MultiSelect = false;
            this.dgvLop.Name = "dgvLop";
            this.dgvLop.ReadOnly = true;
            this.dgvLop.RowHeadersWidth = 51;
            this.dgvLop.RowTemplate.Height = 29;
            this.dgvLop.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvLop.Size = new System.Drawing.Size(1130, 360);
            this.dgvLop.TabIndex = 2;
            this.dgvLop.SelectionChanged += new System.EventHandler(this.dgvLop_SelectionChanged);
            // 
            // FrmMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1184, 696);
            this.Controls.Add(this.tabControl);
            this.Controls.Add(this.lblWelcome);
            this.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.Name = "FrmMain";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Quản lý sinh viên";
            this.Load += new System.EventHandler(this.FrmMain_Load);
            this.tabControl.ResumeLayout(false);
            this.tabSinhVien.ResumeLayout(false);
            this.tabSinhVien.PerformLayout();
            this.grpSinhVien.ResumeLayout(false);
            this.grpSinhVien.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvSinhVien)).EndInit();
            this.tabLop.ResumeLayout(false);
            this.tabLop.PerformLayout();
            this.grpLop.ResumeLayout(false);
            this.grpLop.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvLop)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }
    }
}

