using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Btap_QLSV.BLL;
using Btap_QLSV.UI;

namespace Btap_QLSV
{
    public partial class Form1 : Form
    {
        private readonly AuthService _auth = new AuthService();

        public Form1()
        {
            InitializeComponent();
        }

        private void btnDangNhap_Click(object sender, EventArgs e)
        {
            var u = txtTaiKhoan.Text.Trim();
            var p = txtMatKhau.Text;

            if (!_auth.Login(u, p))
            {
                MessageBox.Show("Sai tài khoản hoặc mật khẩu.", "Đăng nhập thất bại",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtMatKhau.Focus();
                txtMatKhau.SelectAll();
                return;
            }

            Hide();
            var main = new FrmMain(u);
            main.FormClosed += (s, args) => Close();
            main.Show();
        }

        private void lblMatKhau_Click(object sender, EventArgs e)
        {

        }

        private void lblTaiKhoan_Click(object sender, EventArgs e)
        {

        }

        private void txtTaiKhoan_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
