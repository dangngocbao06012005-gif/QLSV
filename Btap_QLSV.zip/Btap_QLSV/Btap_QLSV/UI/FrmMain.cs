using System;
using System.Data;
using System.Drawing;
using System.Windows.Forms;
using Btap_QLSV.BLL;

namespace Btap_QLSV.UI
{
    public partial class FrmMain : Form
    {
        private readonly SinhVienService _svService = new SinhVienService();
        private readonly LopService _lopService = new LopService();

        private DataTable _lopTable;
        private Panel _headerPanel;
        private Label _titleLabel;

        public FrmMain(string loggedInUsername)
        {
            InitializeComponent();
            lblWelcome.Text = $"Xin chào: {loggedInUsername}";
        }

        private void FrmMain_Load(object sender, EventArgs e)
        {
            ApplyTheme();
            LoadLop();
            LoadSinhVien();
            LoadLopGrid();
        }

        private void ApplyTheme()
        {
            BackColor = Color.White;
            tabControl.Appearance = TabAppearance.Normal;
            tabControl.DrawMode = TabDrawMode.OwnerDrawFixed;
            tabControl.DrawItem -= tabControl_DrawItem;
            tabControl.DrawItem += tabControl_DrawItem;
            tabControl.Padding = new Point(18, 6);

            lblWelcome.ForeColor = Color.FromArgb(55, 65, 81);

            ApplyHeader();
            ApplyTypography();
            StyleGrid(dgvSinhVien);
            StyleGrid(dgvLop);

            // Buttons (SinhVien)
            StylePrimaryButton(btnSvSearch);
            StyleNeutralButton(btnSvReload);
            StylePrimaryButton(btnSvAdd);
            StylePrimaryButton(btnSvUpdate);
            StyleDangerButton(btnSvDelete);
            StyleNeutralButton(btnSvClear);

            // Buttons (Lop)
            StylePrimaryButton(btnLopSearch);
            StylePrimaryButton(btnLopAdd);
            StylePrimaryButton(btnLopUpdate);
            StyleDangerButton(btnLopDelete);
            StyleNeutralButton(btnLopClear);

            StyleSearchBox(txtSvSearch);
            StyleSearchBox(txtLopSearch);
        }

        private void ApplyHeader()
        {
            if (_headerPanel != null) return;

            _headerPanel = new Panel
            {
                Dock = DockStyle.Top,
                Height = 56,
                BackColor = Color.FromArgb(37, 99, 235)
            };

            _titleLabel = new Label
            {
                AutoSize = true,
                Text = "HỆ THỐNG QUẢN LÝ SINH VIÊN",
                ForeColor = Color.White,
                Font = new Font("Segoe UI", 12F, FontStyle.Bold),
                Location = new Point(14, 16)
            };

            // Move welcome label into header
            Controls.Remove(lblWelcome);
            lblWelcome.AutoSize = true;
            lblWelcome.ForeColor = Color.FromArgb(226, 232, 240);
            lblWelcome.Font = new Font("Segoe UI", 9F, FontStyle.Regular);
            lblWelcome.Anchor = AnchorStyles.Top | AnchorStyles.Right;

            _headerPanel.Controls.Add(_titleLabel);
            _headerPanel.Controls.Add(lblWelcome);
            Controls.Add(_headerPanel);
            _headerPanel.BringToFront();

            // Position welcome on the right
            _headerPanel.Resize += (s, e) =>
            {
                lblWelcome.Location = new Point(_headerPanel.Width - lblWelcome.Width - 14, 18);
            };
            lblWelcome.Location = new Point(_headerPanel.Width - lblWelcome.Width - 14, 18);

            // Shift tab control down a bit
            tabControl.Location = new Point(tabControl.Left, _headerPanel.Bottom + 10);
            tabControl.Height = ClientSize.Height - tabControl.Top - 12;
        }

        private void ApplyTypography()
        {
            Font = new Font("Segoe UI", 9F, FontStyle.Regular);

            grpSinhVien.ForeColor = Color.FromArgb(31, 41, 55);
            grpLop.ForeColor = Color.FromArgb(31, 41, 55);
            grpSinhVien.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            grpLop.Font = new Font("Segoe UI", 9F, FontStyle.Bold);

            txtMaSV.BorderStyle = BorderStyle.FixedSingle;
            txtHoTen.BorderStyle = BorderStyle.FixedSingle;
            txtDiaChi.BorderStyle = BorderStyle.FixedSingle;
            txtMaLop.BorderStyle = BorderStyle.FixedSingle;
            txtTenLop.BorderStyle = BorderStyle.FixedSingle;
        }

        private static void StyleSearchBox(TextBox txt)
        {
            txt.BorderStyle = BorderStyle.FixedSingle;
            txt.BackColor = Color.FromArgb(249, 250, 251);
        }

        private void tabControl_DrawItem(object sender, DrawItemEventArgs e)
        {
            var selected = e.Index == tabControl.SelectedIndex;
            var rect = e.Bounds;
            rect.Inflate(-2, -2);

            using (var back = new SolidBrush(selected ? Color.FromArgb(37, 99, 235) : Color.FromArgb(243, 244, 246)))
            using (var fore = new SolidBrush(selected ? Color.White : Color.FromArgb(31, 41, 55)))
            using (var font = new Font("Segoe UI", 9F, selected ? FontStyle.Bold : FontStyle.Regular))
            {
                e.Graphics.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;
                e.Graphics.FillRectangle(back, rect);

                var text = tabControl.TabPages[e.Index].Text;
                var sf = new StringFormat { Alignment = StringAlignment.Center, LineAlignment = StringAlignment.Center };
                e.Graphics.DrawString(text, font, fore, rect, sf);
            }
        }

        private static void StyleGrid(DataGridView dgv)
        {
            dgv.BorderStyle = BorderStyle.None;
            dgv.BackgroundColor = Color.White;
            dgv.EnableHeadersVisualStyles = false;
            dgv.ColumnHeadersBorderStyle = DataGridViewHeaderBorderStyle.None;
            dgv.ColumnHeadersDefaultCellStyle.BackColor = Color.FromArgb(37, 99, 235);
            dgv.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;
            dgv.ColumnHeadersDefaultCellStyle.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            dgv.ColumnHeadersHeight = 34;

            dgv.DefaultCellStyle.SelectionBackColor = Color.FromArgb(191, 219, 254);
            dgv.DefaultCellStyle.SelectionForeColor = Color.FromArgb(17, 24, 39);
            dgv.AlternatingRowsDefaultCellStyle.BackColor = Color.FromArgb(249, 250, 251);
            dgv.RowHeadersVisible = false;
        }

        private static void StylePrimaryButton(Button btn)
        {
            btn.UseVisualStyleBackColor = false;
            btn.BackColor = Color.FromArgb(37, 99, 235);
            btn.ForeColor = Color.White;
            btn.FlatStyle = FlatStyle.Flat;
            btn.FlatAppearance.BorderSize = 0;
        }

        private static void StyleDangerButton(Button btn)
        {
            btn.UseVisualStyleBackColor = false;
            btn.BackColor = Color.FromArgb(220, 38, 38);
            btn.ForeColor = Color.White;
            btn.FlatStyle = FlatStyle.Flat;
            btn.FlatAppearance.BorderSize = 0;
        }

        private static void StyleNeutralButton(Button btn)
        {
            btn.UseVisualStyleBackColor = false;
            btn.BackColor = Color.FromArgb(229, 231, 235);
            btn.ForeColor = Color.FromArgb(31, 41, 55);
            btn.FlatStyle = FlatStyle.Flat;
            btn.FlatAppearance.BorderSize = 0;
        }

        private void LoadLop()
        {
            _lopTable = _lopService.GetAll();

            cboSvLop.DataSource = _lopTable;
            cboSvLop.DisplayMember = "TenLop";
            cboSvLop.ValueMember = "MaLop";
        }

        private void LoadSinhVien()
        {
            dgvSinhVien.DataSource = _svService.GetAll();
            dgvSinhVien.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
        }

        private void LoadLopGrid()
        {
            dgvLop.DataSource = _lopService.GetAll();
            dgvLop.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
        }

        private void dgvSinhVien_SelectionChanged(object sender, EventArgs e)
        {
            if (dgvSinhVien.CurrentRow == null) return;
            if (dgvSinhVien.CurrentRow.DataBoundItem is DataRowView drv)
            {
                var row = drv.Row;
                txtMaSV.Text = row["MaSV"]?.ToString();
                txtHoTen.Text = row["HoTen"]?.ToString();
                if (DateTime.TryParse(row["NgaySinh"]?.ToString(), out var d))
                    dtpNgaySinh.Value = d;
                cboGioiTinh.Text = row["GioiTinh"]?.ToString();
                txtDiaChi.Text = row["DiaChi"]?.ToString();
                cboSvLop.SelectedValue = row["MaLop"]?.ToString();
            }
        }

        private void btnSvClear_Click(object sender, EventArgs e)
        {
            txtMaSV.Clear();
            txtHoTen.Clear();
            txtDiaChi.Clear();
            cboGioiTinh.SelectedIndex = 0;
            if (cboSvLop.Items.Count > 0) cboSvLop.SelectedIndex = 0;
            dtpNgaySinh.Value = DateTime.Today;
            txtMaSV.Focus();
        }

        private void btnSvAdd_Click(object sender, EventArgs e)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(txtMaSV.Text) || string.IsNullOrWhiteSpace(txtHoTen.Text))
                {
                    MessageBox.Show("Vui lòng nhập Mã SV và Họ tên.", "Thiếu dữ liệu",
                        MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                var maLop = cboSvLop.SelectedValue?.ToString();
                _svService.Add(txtMaSV.Text, txtHoTen.Text, dtpNgaySinh.Value.Date, cboGioiTinh.Text, txtDiaChi.Text, maLop);
                LoadSinhVien();
                btnSvClear.PerformClick();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Không thể thêm sinh viên.\n\n" + ex.Message, "Lỗi",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnSvUpdate_Click(object sender, EventArgs e)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(txtMaSV.Text))
                {
                    MessageBox.Show("Vui lòng chọn sinh viên cần sửa.", "Thiếu dữ liệu",
                        MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                var maLop = cboSvLop.SelectedValue?.ToString();
                _svService.Update(txtMaSV.Text, txtHoTen.Text, dtpNgaySinh.Value.Date, cboGioiTinh.Text, txtDiaChi.Text, maLop);
                LoadSinhVien();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Không thể cập nhật sinh viên.\n\n" + ex.Message, "Lỗi",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnSvDelete_Click(object sender, EventArgs e)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(txtMaSV.Text))
                {
                    MessageBox.Show("Vui lòng chọn sinh viên cần xóa.", "Thiếu dữ liệu",
                        MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                var ok = MessageBox.Show("Xóa sinh viên này?", "Xác nhận",
                    MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (ok != DialogResult.Yes) return;

                _svService.Delete(txtMaSV.Text);
                LoadSinhVien();
                btnSvClear.PerformClick();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Không thể xóa sinh viên.\n\n" + ex.Message, "Lỗi",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnSvSearch_Click(object sender, EventArgs e)
        {
            try
            {
                dgvSinhVien.DataSource = _svService.Search(txtSvSearch.Text);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Không thể tìm kiếm.\n\n" + ex.Message, "Lỗi",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnSvReload_Click(object sender, EventArgs e)
        {
            LoadLop();
            LoadSinhVien();
        }

        private void dgvLop_SelectionChanged(object sender, EventArgs e)
        {
            if (dgvLop.CurrentRow == null) return;
            if (dgvLop.CurrentRow.DataBoundItem is DataRowView drv)
            {
                var row = drv.Row;
                txtMaLop.Text = row["MaLop"]?.ToString();
                txtTenLop.Text = row["TenLop"]?.ToString();
            }
        }

        private void btnLopClear_Click(object sender, EventArgs e)
        {
            txtMaLop.Clear();
            txtTenLop.Clear();
            txtMaLop.Focus();
        }

        private void btnLopAdd_Click(object sender, EventArgs e)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(txtMaLop.Text) || string.IsNullOrWhiteSpace(txtTenLop.Text))
                {
                    MessageBox.Show("Vui lòng nhập Mã lớp và Tên lớp.", "Thiếu dữ liệu",
                        MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                _lopService.Add(txtMaLop.Text, txtTenLop.Text);
                LoadLop();
                LoadLopGrid();
                btnLopClear.PerformClick();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Không thể thêm lớp.\n\n" + ex.Message, "Lỗi",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnLopUpdate_Click(object sender, EventArgs e)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(txtMaLop.Text))
                {
                    MessageBox.Show("Vui lòng chọn lớp cần sửa.", "Thiếu dữ liệu",
                        MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                _lopService.Update(txtMaLop.Text, txtTenLop.Text);
                LoadLop();
                LoadLopGrid();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Không thể cập nhật lớp.\n\n" + ex.Message, "Lỗi",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnLopDelete_Click(object sender, EventArgs e)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(txtMaLop.Text))
                {
                    MessageBox.Show("Vui lòng chọn lớp cần xóa.", "Thiếu dữ liệu",
                        MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                var ok = MessageBox.Show("Xóa lớp này? (Nếu lớp đang có sinh viên, bạn phải xóa sinh viên trước.)",
                    "Xác nhận", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (ok != DialogResult.Yes) return;

                _lopService.Delete(txtMaLop.Text);
                LoadLop();
                LoadLopGrid();
                btnLopClear.PerformClick();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Không thể xóa lớp.\n\n" + ex.Message, "Lỗi",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnLopSearch_Click(object sender, EventArgs e)
        {
            try
            {
                dgvLop.DataSource = _lopService.Search(txtLopSearch.Text);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Không thể tìm kiếm lớp.\n\n" + ex.Message, "Lỗi",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void txtSvSearch_TextChanged(object sender, EventArgs e)
        {

        }

        private void grpSinhVien_Enter(object sender, EventArgs e)
        {

        }
    }
}

